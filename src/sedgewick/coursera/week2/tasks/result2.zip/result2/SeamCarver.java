import edu.princeton.cs.algs4.Picture;

public class SeamCarver {
    private Picture picture;
    private static final double BORDER_ENERGY = 1000.;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        if (picture == null) {
            throw new IllegalArgumentException();
        }
        // The data type may not mutate the Picture argument to the constructor
        this.picture = new Picture(picture);
    }

    private class RGB {
        private final int red;
        private final int green;
        private final int blue;

        public RGB(int idx) {
            red = (idx >> 16) & 0XFF;
            green = (idx >> 8) & 0XFF;
            blue = (idx >> 0) & 0XFF;
        }

        public String toString() {
            return String.format("(%3d, %3d, %3d)", red, green, blue);
        }
    }


    // current picture
    public Picture picture() {
        return new Picture(picture);
    }

    // width of current picture
    public int width() {
        return picture.width();
    }

    // height of current picture
    public int height() {
        return picture.height();
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        if (x < 0 || x > width() - 1 || y < 0 || y > height() - 1) {
            throw new IllegalArgumentException();
        }
        if (x == 0 || x == width() - 1 || y == 0 || y == height() - 1) {
            return BORDER_ENERGY;
        }

        RGB rgbX = new RGB(picture.getRGB(x - 1, y));
        RGB rgbX1 = new RGB(picture.getRGB(x + 1, y));
        RGB rgbY = new RGB(picture.getRGB(x, y - 1))
        RGB rgbY1 = new RGB(picture.getRGB(x, y + 1));

        double gradRx = rgbX.red - rgbX1.red;
        double gradGx = rgbX.green - rgbX1.green;
        double gradBx = rgbX.blue - rgbX1.blue;

        double gradRy = rgbY.red - rgbY1.red;
        double gradGy = rgbY.red - rgbY1.red;
        double gradBy = rgbY.red - rgbY1.red;

        return Math.sqrt(gradRx * gradRx + gradGx * gradGx + gradBx * gradBx +
                gradRy * gradRy + gradGy * gradGy + gradBy * gradBy);
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        transposePicture();
        int[] seam = findVerticalSeam();
        transposePicture();
        return seam;
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        double[][] energy = new double[height()][];
        double[][] distTo = new double[height()][];
        int[][] edgeTo = new int[height()][];

        for (int row = 0; row < height(); ++row) {
            energy[row] = new double[width()];
            distTo[row] = new double[width()];
            edgeTo[row] = new int[width()];
            for (int col = 0; col < width(); ++col) {
                energy[row][col] = energy(col, row);
                distTo[row][col] = row == 0 ? 0 : Double.POSITIVE_INFINITY;
                edgeTo[row][col] = -1;
            }
        }

        // Topography search
        for (int row = 0; row < height() - 1; ++row) {
            for (int col = 0; col < width(); ++col) {
                int nextRow = row + 1;
                for (int nextCol = col - 1; nextCol <= col + 1; ++nextCol) {
                    if (nextCol >= 0 && nextCol < width()) {
                        double weight = energy[nextRow][nextCol];
                        if (distTo[nextRow][nextCol] > distTo[row][col] + weight) {
                            distTo[nextRow][nextCol] = distTo[row][col] + weight;
                            edgeTo[nextRow][nextCol] = col;
                        }
                    }
                }
            }
        }

        int[] seam = new int[height()];
        double min = Double.POSITIVE_INFINITY;
        int lowCol = -1;
        for (int col = 0; col < width(); col++) {
            if (min > distTo[height() - 1][col]) {
                lowCol = col;
                min = distTo[height() - 1][col];
            }
        }
        assert (lowCol > 0);
        for (int row = height() - 1; row >= 0; row--) {
            seam[row] = lowCol;
            lowCol = edgeTo[row][lowCol];
        }

        return seam;
    }

    public void removeHorizontalSeam(int[] seam) {
        transposePicture();
        removeVerticalSeam(seam);
        transposePicture();
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (picture.width() <= 1) {
            throw new IllegalArgumentException("insufficient picture width");
        }
        validateSeam(seam);

        // replace picture with smaller image - very slow
        Picture trimmed = new Picture(width() - 1, height());
        for (int row = 0; row < height(); row++) {
            int trimColumn = seam[row];
            for (int col = 0; col < trimColumn; col++) {
                trimmed.setRGB(col, row, picture.getRGB(col, row));
            }
            for (int col = trimColumn + 1; col < width(); col++) {
                trimmed.setRGB(col - 1, row, picture.getRGB(col, row));
            }
        }
        this.picture = trimmed;
    }

    private void transposePicture() {
        Picture transpose = new Picture(height(), width());
        for (int col = 0; col < width(); col++) {
            for (int row = 0; row < height(); row++) {
                transpose.setRGB(row, col, picture.getRGB(col, row));
            }
        }
        this.picture = transpose;
    }

    private void validateSeam(int[] seam) {
        if (seam == null) {
            throw new IllegalArgumentException("seam is null");
        }

        if (seam.length != height()) {
            throw new IllegalArgumentException("seam length does not match range of " + picture.height());
        }

        int prev = seam[0];
        if (prev < 0 || prev >= width()) {
            throw new IllegalArgumentException("seam entry " + prev + " is outside prescribed range of " + picture.width());
        }
        for (int i = 1; i < seam.length; ++i) {
            int curr = seam[i];
            if (Math.abs(curr - prev) > 1) {
                throw new IllegalArgumentException("adjacent seam entries are too var apart");
            }
            if (curr < 0 || curr >= width()) {
                throw new IllegalArgumentException("seam entry " + i + " is outside prescribed range of " + picture.width());
            }
            prev = curr;
        }
    }
}